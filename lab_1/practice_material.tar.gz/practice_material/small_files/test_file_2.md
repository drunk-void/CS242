Test file 2 with .md extension
