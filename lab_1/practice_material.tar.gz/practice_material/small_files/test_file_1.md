Test file 1 with .md extension
