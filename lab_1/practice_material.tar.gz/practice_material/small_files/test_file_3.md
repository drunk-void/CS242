Test file 3 with .md extension
